const t={apiKey:"",teamId:null,teamName:null,projectId:null,projectName:null,capturePatterns:["/api/*","*/graphql"]},a=20,e="lbc-interceptor",c="lbc-config";export{a as B,c as C,t as D,e as I};
