const y="https://api.linear.app/graphql";async function o(e,r,n){const a=await(await fetch(y,{method:"POST",headers:{"Content-Type":"application/json",Authorization:e},body:JSON.stringify({query:r,variables:n})})).json();if(a.errors)throw new Error(a.errors.map(i=>i.message).join("; "));return a.data}async function b(e){const r=await o(e,`query {
      viewer { id name email }
      teams(first: 250) { nodes { id name } }
    }`);return{viewer:r.viewer,teams:r.teams.nodes.map(n=>({id:n.id,name:n.name,projects:[]}))}}async function g(e,r){return(await o(e,`query TeamProjects($id: String!) {
      team(id: $id) { projects(first: 250) { nodes { id name } } }
    }`,{id:r})).team.projects.nodes}async function j(e,r){var u;const n=await(await fetch(r)).blob(),t=n.type||"image/png",a=`bug-catcher-${Date.now()}.png`,i=await o(e,`mutation FileUpload($contentType: String!, $filename: String!, $size: Int!) {
      fileUpload(contentType: $contentType, filename: $filename, size: $size) {
        success
        uploadFile { uploadUrl assetUrl headers { key value } }
      }
    }`,{contentType:t,filename:a,size:n.size});if(!((u=i.fileUpload)!=null&&u.success))throw new Error("Linear rejected the file upload");const{uploadUrl:f,assetUrl:m,headers:w}=i.fileUpload.uploadFile,s=new Headers({"Content-Type":t});for(const d of w)s.set(d.key,d.value);const c=await fetch(f,{method:"PUT",headers:s,body:n});if(!c.ok)throw new Error(`Image upload failed (${c.status})`);return m}function I(e){const r={request:{method:e.method,url:e.url,headers:e.requestHeaders,body:l(e.requestBody)},response:{status:e.status,headers:e.responseHeaders,body:l(e.responseBody)}};return`### ${e.ok?"":"🔴 "}\`${e.method} ${e.url} — ${e.status}\`

\`\`\`json
${JSON.stringify(r,null,2)}
\`\`\``}function l(e){if(e==null)return null;try{return JSON.parse(e)}catch{return e}}async function $(e){var i;const r=await j(e.apiKey,e.screenshotBase64),n=[];e.description.trim()&&n.push(e.description.trim()),n.push(`## Screenshot

![screenshot](${r})`),e.logs.length&&n.push(`## Network logs

${e.logs.map(I).join(`

`)}`);const t=n.join(`

`),a=await o(e.apiKey,`mutation IssueCreate($input: IssueCreateInput!) {
      issueCreate(input: $input) { success issue { url identifier } }
    }`,{input:{teamId:e.teamId,title:e.title,description:t,...e.projectId?{projectId:e.projectId}:{}}});if(!((i=a.issueCreate)!=null&&i.success))throw new Error("Linear rejected the issue");return a.issueCreate.issue}function S(e){return new Promise(r=>setTimeout(r,e))}function h(e,r){return chrome.tabs.sendMessage(e,{type:"OPEN_MODAL",screenshot:r}).then(()=>!0).catch(()=>!1)}async function T(e){const n=(chrome.runtime.getManifest().content_scripts??[]).find(a=>a.world!=="MAIN"),t=n==null?void 0:n.js;if(!(t!=null&&t.length))return!1;try{return await chrome.scripting.executeScript({target:{tabId:e},files:t}),!0}catch(a){return console.error("[bug-catcher] executeScript failed",a),!1}}async function p(e){const r=e??(await chrome.tabs.query({active:!0,currentWindow:!0}))[0];if(!(r!=null&&r.id)||r.windowId==null||r.url&&/^(chrome|edge|about|chrome-extension|https:\/\/chromewebstore)/.test(r.url))return;let n;try{n=await chrome.tabs.captureVisibleTab(r.windowId,{format:"png"})}catch(t){console.error("[bug-catcher] captureVisibleTab failed",t);return}if(!await h(r.id,n)){if(!await T(r.id)){console.error("[bug-catcher] content script not reachable (reload the tab)");return}for(let t=0;t<15;t++)if(await S(120),await h(r.id,n))return;console.error("[bug-catcher] could not open modal after injection (reload the tab)")}}chrome.action.onClicked.addListener(e=>void p(e));chrome.commands.onCommand.addListener(e=>{e==="open-bug-catcher"&&p()});chrome.runtime.onMessage.addListener((e,r,n)=>{if(e.type==="LINEAR_CONNECT")return b(e.apiKey).then(t=>n({ok:!0,...t})).catch(t=>n({ok:!1,error:String((t==null?void 0:t.message)??t)})),!0;if(e.type==="LINEAR_PROJECTS")return g(e.apiKey,e.teamId).then(t=>n({ok:!0,projects:t})).catch(t=>n({ok:!1,error:String((t==null?void 0:t.message)??t)})),!0;if(e.type==="CREATE_ISSUE")return $(e.payload).then(t=>n({ok:!0,...t})).catch(t=>n({ok:!1,error:String((t==null?void 0:t.message)??t)})),!0});
